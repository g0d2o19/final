require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const User = require('./models/User');
const Portfolio = require('./models/Portfolio');
const multer = require('multer');
const path = require('path');
const app = express();

app.use(express.static('public'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true },
  })
);

mongoose.connect(process.env.MONGODB_URL).then(() => console.log('Connected to MongoDB'));

async function seedAdmin() {
  const adminExists = await User.findOne({ username: 'admin' });
  if (!adminExists) {
    const hashedPassword = await bcrypt.hash('123456', 10);
    const adminUser = new User({
      username: 'admin',
      password: '123456',
      firstName: 'MILANA',
      lastName: 'STYOPKINA',
      age: 19,
      gender: 'female',
      email: 'milana.super16@gmail.com',
      role: 'admin',
      twoFactorSecret: null,
    });
    await adminUser.save();
    console.log('Admin user created.');
  }
}
seedAdmin();

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail', 
  auth: {
    user: process.env.EMAIL_USER,  
    pass: process.env.EMAIL_PASS, 
  },
});

async function sendWelcomeEmail(userEmail) {
  const mailOptions = {
    from: process.env.EMAIL_USER, 
    to: userEmail,
    subject: 'Welcome to MilanaS!', 
    text: 'Thank you for registering with MilanaS. We are excited to have you on board!',  
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Welcome email sent');
  } catch (error) {
    console.error('Error sending email:', error);
  }
}
async function sendLoginEmail(userEmail) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: userEmail,
    subject: 'Login Notification',
    text: 'You have successfully logged into your account at MilanaS!',
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Login email sent');
  } catch (error) {
    console.error('Error sending login email:', error);
  }
}


function ensureAuthenticated(req, res, next) {
  if (req.session.user) {
    return next();
  }
  res.redirect('/login');
}

app.get('/', async (req, res) => {
  try {
    const portfolioItems = await Portfolio.find();
    res.render('index', { user: null, portfolioItems });
  } catch (error) {
    console.error('Error loading home page:', error);
    res.status(500).send('Error loading home page.');
  }
});

app.get('/register', (req, res) => res.render('register'));

app.post('/register', async (req, res) => {
  const { username, password, firstName, lastName, age, gender, email } = req.body;

  try {
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
      const message = existingUser.username === username && existingUser.email === email
        ? 'Both username and email are already registered.'
        : existingUser.username === username
        ? 'Username is already taken.'
        : 'Email is already registered.';
      return res.render('register', { message });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const twoFactorSecret = speakeasy.generateSecret({ name: 'MilanaS' });
    const user = new User({
      username,
      password: hashedPassword,
      firstName,
      lastName,
      age,
      gender,
      email,
      role: 'editor',
      twoFactorSecret: twoFactorSecret.base32,
    });

    await user.save();
    await sendWelcomeEmail(email);

    const twoFactorQRCode = await qrcode.toDataURL(twoFactorSecret.otpauth_url);
    res.render('2fa-setup', { twoFactorQRCode });
  } catch (error) {
    console.error('Registration error:', error);
    res.render('register', { message: 'An error occurred. Please try again.' });
  }
});

app.get('/login', (req, res) => res.render('login', { message: null }));

app.post('/users/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) {
      return res.render('login', { message: 'User not found.' });
    }

    const passwordValid = await bcrypt.compare(password, user.password);
    if (!passwordValid) {
      return res.render('login', { message: 'Invalid password.' });
    }

    req.session.user = { id: user._id, role: user.role };

    await sendLoginEmail(user.email);

    if (!user.twoFactorSecret) {
      return res.redirect('/2fa');
    }

    res.redirect('/dashboard');
  } catch (error) {
    console.error('Login error:', error);
    res.render('login', { message: 'An error occurred. Please try again.' });
  }
});

app.get('/2fa', ensureAuthenticated, async (req, res) => {
  const user = await User.findById(req.session.user.id);
  if (!user.twoFactorSecret) {
    return res.redirect('/dashboard'); 
  }

  const twoFactorQRCode = await qrcode.toDataURL(
    speakeasy.otpauthURL({ secret: user.twoFactorSecret, label: 'MilanaS' })
  );

  res.render('2fa-setup', { twoFactorQRCode });
});

app.post('/2fa/verify', ensureAuthenticated, async (req, res) => {
  const { token } = req.body;
  const user = await User.findById(req.session.user.id);
  const verified = speakeasy.totp.verify({
    secret: user.twoFactorSecret,
    encoding: 'base32',
    token,
  });

  if (verified) {
    req.session.user.twoFactorVerified = true;
    res.redirect('/dashboard');
  } else {
    res.render('2fa-setup', { error: 'Invalid token. Please try again.' });
  }
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/uploads'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage });

app.get('/dashboard', ensureAuthenticated, async (req, res) => {
  try {
    const user = req.session.user || null;
    const portfolioItems = await Portfolio.find(); 
    res.render('dashboard', { user, role: user?.role, portfolioItems });
  } catch (error) {
    console.error('Error loading dashboard:', error);
    res.status(500).send('Error loading dashboard.');
  }
});

app.post('/portfolio', ensureAuthenticated, upload.array('images', 3), async (req, res) => {
  const { title, description } = req.body;
  const images = req.files.map((file) => `/uploads/${file.filename}`); 

  try {
    const portfolioItem = new Portfolio({
      title,
      description,
      images,
      createdBy: req.session.user.id, 
    });
    await portfolioItem.save();
    res.redirect('/dashboard'); 
  } catch (error) {
    console.error('Error creating portfolio item:', error);
    res.status(500).send('Failed to create portfolio item.');
  }
});

app.post('/delete-portfolio/:id', ensureAuthenticated, async (req, res) => {
  if (req.session.user.role !== 'admin') {
    return res.status(403).send('Permission denied.');
  }

  try {
    await Portfolio.findByIdAndDelete(req.params.id);
    res.json({ message: 'Portfolio item deleted successfully.' });
  } catch (error) {
    console.error('Error deleting portfolio item:', error);
    res.status(500).send('Failed to delete portfolio item.');
  }
});

app.post('/update-portfolio/:id', ensureAuthenticated, upload.array('images', 3), async (req, res) => {
  const { title, description } = req.body;
  const images = req.files ? req.files.map((file) => `/uploads/${file.filename}`) : [];

  try {
    const portfolioItem = await Portfolio.findById(req.params.id);
    if (!portfolioItem) {
      return res.status(404).json({ error: 'Portfolio item not found.' });
    }

    portfolioItem.title = title;
    portfolioItem.description = description;
    portfolioItem.images = images.length > 0 ? images : portfolioItem.images;
    portfolioItem.updatedAt = Date.now();

    await portfolioItem.save();
    res.json({ message: 'Portfolio item updated successfully.' });
  } catch (error) {
    console.error('Error updating portfolio item:', error);
    res.status(500).json({ error: 'Failed to update portfolio item.' });
  }
});

app.get('/portfolio/:id', (req, res) => {
  const itemId = req.params.id;
  if (!mongoose.Types.ObjectId.isValid(itemId)) {
    return res.status(400).json({ error: 'Invalid ID format' });
  }
  Portfolio.findById(itemId, (err, item) => {
    if (err || !item) {
      return res.status(404).json({ error: 'Item not found' });
    }
    res.json(item);
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

app.get('/portfolio', async (req, res) => {
  const portfolioItems = await Portfolio.find();
  res.json(portfolioItems); 
});

app.get('/chart', (req, res) => {
  const chartData = {
    type: 'doughnut',
    data: {
      datasets: [
        {
          data: [1, 2, 97],
          backgroundColor: ['rgb(255, 205, 86)', 'rgb(75, 192, 192)', 'rgb(54, 162, 235)'],
          label: 'вода',
        },
      ],
      labels: ['Rivers and Lakes', 'Icebergs', 'Ocean'],
    },
    options: {
      title: {
        display: true,
        text: 'Earth Water Distribution',
      },
    },
  };

  console.log(chartData);
  res.json(chartData);
});
