const { MongoClient } = require("mongodb");

const mongoURI = "mongodb+srv://230397:ogAco5ws0p607cR3@cluster0.waqss.mongodb.net/todolistDB?retryWrites=true&w=majority";
const client = new MongoClient(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true });

async function connectToMongo() {
  try {
    await client.connect();
    console.log("Connected to MongoDB");
    return client.db("todolistDB"); // Возвращаем базу данных
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    throw error;
  }
}

module.exports = { connectToMongo };
